$(document).ready(function () {
  // const config = {
  //   parent, //madatory
  //   item, //madatory
  //   event ,
  //   navimation: {
  //     css,
  //     id ,
  //     background,
  //     height ,
  //     timeTranslate ,
  //     timeHide ,
  //     attr,
  //   } ,
  // }

  navimation({
    parent: $("ul"),
    item: $("li"),
    event : "mouseenter" ,
    navimationTag: {
      background: "unset",
      id: "navimation",
      height: "2px",
      timeTranslate: "0.5s",
      timeFunctionTranslate: "ease-out",
      timeHide: "0.5s",
      timeFunctionHide: "linear",
      css: {
        "background-image": "linear-gradient(90deg, rgba(36,0,0,0) 0%, rgba(142,8,8,1) 30%, rgba(147,8,8,1) 70%, rgba(255,0,0,0) 100%)",
      },
      attr: {
        "data-id": "1234",
      },
    },
  });
});

$("#").pDat()
class person {
  constructor(){

  }

  handleSubmit(){

  }
}
const obj=new person();
obj.handleSubmit
obj()